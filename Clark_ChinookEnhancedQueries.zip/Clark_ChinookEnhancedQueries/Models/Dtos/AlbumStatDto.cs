using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Clark_ChinookEnhancedQueries.Models.Dtos
{
    public class AlbumStatDto
    {
        public string? Title { get; set; }
        public int TrackCount { get; set; }
    }
}